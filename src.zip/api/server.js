const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to parse JSON requests
app.use(express.json());

// Utility function to read users.json
const readUsers = () => {
  const data = fs.readFileSync(path.join(__dirname, 'users.json'));
  return JSON.parse(data);
};

// Utility function to write to users.json
const writeUsers = (users) => {
  fs.writeFileSync(
    path.join(__dirname, 'users.json'),
    JSON.stringify(users, null, 2)
  );
};

// Endpoint to get unique users
app.get('/uniqueUsers', (req, res) => {
  const users = readUsers();
  const uniqueUsers = [
    ...new Map(users.map((user) => [user.name, user])).values(),
  ]; // Ensure unique users
  res.json(uniqueUsers);
});

// Endpoint to get users ordered by department and designation
app.get('/orderedUsers', (req, res) => {
  const users = readUsers();
  const orderedUsers = users.sort((a, b) => {
    if (a.department < b.department) return -1;
    if (a.department > b.department) return 1;
    return a.designation < b.designation ? -1 : 1;
  });
  res.json(orderedUsers);
});

// Endpoint to add a new user
app.post('/addUser', (req, res) => {
  const newUser = req.body;
  const users = readUsers();
  users.push(newUser);
  writeUsers(users);
  res.status(201).json(newUser);
});

// Endpoint to update an existing user
app.put('/updateUser/:name', (req, res) => {
  const { name } = req.params;
  const updatedUser = req.body;
  const users = readUsers();
  const index = users.findIndex((user) => user.name === name);

  if (index !== -1) {
    users[index] = updatedUser;
    writeUsers(users);
    res.json(updatedUser);
  } else {
    res.status(404).json({ message: 'User not found' });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
