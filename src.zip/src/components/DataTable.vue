<template>
  <div>
    <!-- Add your previous code here -->
    <button @click="saveUser">Save User</button>
    <button @click="loadUsers">Load Users</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      newUser: { name: '', designation: '', department: '' }, // For saving a new user
      users: [], // To store loaded users
    };
  },
  methods: {
    // Save new user to the mock API
    async saveUser() {
      try {
        const response = await fetch('https://86d5d031-5496-4abe-a9bf-6362a7aa52ee.mock.pstmn.io/addUser', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(this.newUser), // Sending the new user as the request body
        });

        if (response.ok) {
          const result = await response.json();
          console.log(result.message); // Log success message from the server
        } else {
          console.error('Failed to save user');
        }
      } catch (error) {
        console.error(error);
      }
    },

    // Load users from the mock API
    async loadUsers() {
      try {
        const response = await fetch('https://86d5d031-5496-4abe-a9bf-6362a7aa52ee.mock.pstmn.io/uniqueUsers');
        
        if (response.ok) {
          const users = await response.json();
          console.log(users);
          this.users = users; // Set the fetched users data to the `users` array
        } else {
          console.error('Failed to load users');
        }
      } catch (error) {
        console.error(error);
      }
    },

  },
};
</script>
