<template>
  <div>
    <!-- Heading for the Pie Chart -->
    <h2>Real-Time Pie Chart</h2>

    <!-- Pie Chart Component -->
    <PieChart :chart-data="chartData" :options="options" />
  </div>
</template>

<script>
import { Pie } from 'vue-chartjs';
import { Chart as ChartJS, Title, Tooltip, Legend, ArcElement } from 'chart.js';

// Register necessary components for Chart.js
ChartJS.register(Title, Tooltip, Legend, ArcElement);

export default {
  components: {
    PieChart: Pie,
  },
  data() {
    return {
      chartData: null, // Initially null to load data later
      options: {
        responsive: true,
        maintainAspectRatio: false,
      },
    };
  },
  mounted() {
    // Fetch the data from pieChart.json when the component mounts
    fetch('/public/pieChart.json')
      .then((response) => response.json())
      .then((data) => {
        this.chartData = {
          labels: data.labels,
          datasets: [
            {
              backgroundColor: data.colors,
              data: data.values,
            },
          ],
        };
      });
  },
};
</script>

<style scoped>
div {
  width: 80%;
  margin: auto;
}
</style>
