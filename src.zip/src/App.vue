<template>
  <div id="app">
    <!-- Use the PieChart and DataTable components here -->
    <PieChart />
    <DataTable />
  </div>
</template>

<script>
// Import the necessary components
import PieChart from './components/PieChart.vue';
import DataTable from './components/DataTable.vue';

export default {
  components: {
    PieChart,
    DataTable,
  },
};
</script>

<style>
/* Add some padding around the app */
#app {
  text-align: center;
  padding: 20px;
}
</style>
