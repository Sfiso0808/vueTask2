

// Open IndexedDB
const openDB = (dbName, storeName) => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(dbName, 1);

    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(storeName)) {
        db.createObjectStore(storeName, { keyPath: 'id', autoIncrement: true });
      }
    };

    request.onsuccess = (event) => {
      resolve(event.target.result);
    };

    request.onerror = (event) => {
      reject('Error opening DB: ' + event.target.errorCode);
    };
  });
};

// Encrypt data (example with a simple Base64 encoding for demonstration)
const encryptData = (data) => {
  return btoa(JSON.stringify(data)); 
};

// Decrypt data
const decryptData = (data) => {
  return JSON.parse(atob(data)); // Decode the base64 encoded string
};

// CRUD Operations
export const dbOperations = {
  async addItem(dbName, storeName, item) {
    const db = await openDB(dbName, storeName);
    const encryptedItem = encryptData(item);

    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    store.add({ ...item, encryptedData: encryptedItem });

    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => {
        resolve();
      };
      transaction.onerror = (event) => {
        reject('Error adding item: ' + event.target.errorCode);
      };
    });
  },

  async getItems(dbName, storeName) {
    const db = await openDB(dbName, storeName);
    return new Promise((resolve) => {
      const transaction = db.transaction(storeName, 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.getAll();

      request.onsuccess = () => {
        const decryptedItems = request.result.map((item) => ({
          ...item,
          decryptedData: decryptData(item.encryptedData),
        }));
        resolve(decryptedItems);
      };
    });
  },

  async updateItem(dbName, storeName, id, newItem) {
    const db = await openDB(dbName, storeName);
    const encryptedItem = encryptData(newItem);

    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    store.put({ ...newItem, id, encryptedData: encryptedItem });

    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => {
        resolve();
      };
      transaction.onerror = (event) => {
        reject('Error updating item: ' + event.target.errorCode);
      };
    });
  },

  async deleteItem(dbName, storeName, id) {
    const db = await openDB(dbName, storeName);
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    store.delete(id);

    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => {
        resolve();
      };
      transaction.onerror = (event) => {
        reject('Error deleting item: ' + event.target.errorCode);
      };
    });
  },
};
